
package lcs;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author h63z978
 */
public class Driver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException, IOException {
       
        File file = new File ("in.txt");
        BufferedReader reader = new BufferedReader (new FileReader(file));
        
        char [] eyeless = new char[1000];
        char [] anaridia = new char[900];
        
        eyeless[0] = 0;
        anaridia[0] = 0;
        
        
        String line = reader.readLine();    //skips info line
        char nextChar = (char)reader.read();
        
        for(int i = 1 ; i < 900 ; i++){
            if(nextChar == '>')
                break;         
            anaridia[i] = nextChar;
            nextChar = (char)reader.read();
            if(Character.isWhitespace(nextChar))
                nextChar = (char)reader.read();
            if(Character.isWhitespace(nextChar))
                nextChar = (char)reader.read();
        }
        
        reader.skip(100);    //skips info line
        for(int i = 1 ; i < 1000 ; i++){
            nextChar = (char)reader.read();
            if(Character.isWhitespace(nextChar))
                nextChar = (char)reader.read();
            if(Character.isWhitespace(nextChar))
                nextChar = (char)reader.read();
            if(nextChar == '>')
                break;
            eyeless[i] = nextChar;
        }
               
        int lenX;
        for(lenX = 1; lenX < 900; lenX++){
            if(anaridia[lenX] == anaridia[899])
                break;
            System.out.print(anaridia[lenX]);
        }
        System.out.println("");
        System.out.println(" --------------------");
        int lenY; 
        for(lenY = 1; lenY < 1000; lenY++){
            if(eyeless[lenY] == eyeless[999])
                break;
            System.out.print(eyeless[lenY]);
        }
        System.out.println("");
        System.out.println("------------------");
        System.out.println(lenX);
        System.out.println(lenY);
        makeGrid(anaridia, eyeless, lenX, lenY);
        char[] anaComp = new char[] {'M', 'Q', 'N', 'S', 'H', 'G', 'V', 'L', 'F', 'R', 'P', 'D', 'T', 'K', 'I', 'E', 'A', 'C', 'Y', 'W'};
        char[] rand1 = getRand(anaComp, lenX);
        char[] rand2 = getRand(anaComp, lenX);
        char[] rand3 = getRand(anaComp, lenX);
        char[] rand4 = getRand(anaComp, lenX);
        char[] rand5 = getRand(anaComp, lenX);
        char[] rand6 = getRand(anaComp, lenX);
        char[] rand7 = getRand(anaComp, lenX);
        char[] rand8 = getRand(anaComp, lenX);
        char[] rand9 = getRand(anaComp, lenX);
        char[] rand0 = getRand(anaComp, lenX);
        
        makeGrid(anaridia, rand1, lenX, lenX);
        makeGrid(anaridia, rand2, lenX, lenX);
        makeGrid(anaridia, rand3, lenX, lenX);
        makeGrid(anaridia, rand4, lenX, lenX);
        makeGrid(anaridia, rand5, lenX, lenX);
        makeGrid(anaridia, rand6, lenX, lenX);
        makeGrid(anaridia, rand7, lenX, lenX);
        makeGrid(anaridia, rand8, lenX, lenX);
        makeGrid(anaridia, rand9, lenX, lenX);
        makeGrid(anaridia, rand0, lenX, lenX);
        
        
    }
    
    public static void makeGrid(char[] anaridia, char[] eyeless, int lenX, int lenY){
        int[][] grid = new int [lenX] [lenY];
        int[][] arrowGrid = new int [lenX] [lenY]; // 1 = up, 2 = diagonal, 3 = left
        
        for(int x = 0; x < (lenX); x++){
            grid[x][0] = 0;
            arrowGrid[x][0] = 0;
        }
        for(int y = 0; y < (lenY); y++){
            grid[0][y] = 0;
            arrowGrid[0][y] = 0;
        }
        
        for(int y = 1; y < lenY; y++){
            for(int x = 1; x < lenX; x++){
                
                if(anaridia[x] == eyeless[y]){
                    grid[x][y] = ++grid[x-1][y-1];
                    arrowGrid[x][y] = 2;
                }
                else{
                    grid[x][y] = Math.max(grid[x-1][y], grid[x][y-1]);
                    arrowGrid[x][y] = (grid[x-1][y] >= grid[x][y-1]) ?  3 : 1;
                }
            }
        }
        System.out.print("LCS is ");
        printLCS( arrowGrid, anaridia, lenX-1, lenY-1);
        System.out.println();
        System.out.println("Alignment score = " + grid[lenX-1][lenY-1]);
    }
    
    
    public static void printLCS(int[][]aGrid, char[] ana, int x, int y){
        if(x == 0 || y == 0)
            return;
        if(aGrid[x][y] == 2){
            printLCS(aGrid, ana, x-1, y-1);
            System.out.print(ana[x]);
        }
        else{
            if (aGrid[x][y] == 1) 
                printLCS(aGrid, ana, x, y-1);
            else
                printLCS(aGrid, ana, x-1, y);
        }
    
    }
    
    public static char[] getRand(char[]comp, int len){
        char[] rand = new char[len];
                    
        for (int i = 1; i < len; i++) {
            int num = (int)(Math.random() * comp.length);
            rand[i] = comp[num]; 
            
        }
        return rand;
    }
    
    
    
    public static int contains(char[] acids, char in){
        for(int i = 0; i < acids.length; i++){
            if (acids[i] == in){
                return i;
            }
        }
        return 666;
    }
}
